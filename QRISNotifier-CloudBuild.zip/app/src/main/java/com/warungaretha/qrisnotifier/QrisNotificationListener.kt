package com.warungaretha.qrisnotifier

import android.service.notification.NotificationListenerService

class QrisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: android.service.notification.StatusBarNotification) {
        val tx = QrisNotificationParser.parse(
            sbn.packageName,
            sbn.notification.extras,
            sbn.postTime
        ) ?: return
        TransactionStore(applicationContext).add(tx)
    }
}
