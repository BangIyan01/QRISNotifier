package com.warungaretha.qrisnotifier

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private val Navy = Color(0xFF0F172A)
private val Green = Color(0xFF16A34A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Green,
                    background = Color(0xFFF8FAFC),
                    surface = Color.White
                )
            ) { QrisApp() }
        }
    }

    fun openNotificationAccess() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    }

    @Composable
    fun QrisApp() {
        var selected by remember { mutableIntStateOf(0) }
        var filter by remember { mutableStateOf("SEMUA") }
        var transactions by remember { mutableStateOf(TransactionStore(this).load()) }

        LaunchedEffect(Unit) {
            while (true) {
                transactions = TransactionStore(this@MainActivity).load()
                kotlinx.coroutines.delay(1500)
            }
        }

        Scaffold(
            topBar = {
                Column(Modifier.background(Navy).padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Text("QRIS Notifier", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Pantau pembayaran DANA & ShopeePay", color = Color(0xFFCBD5E1), fontSize = 13.sp)
                }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected == 0, { selected = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Dashboard") })
                    NavigationBarItem(selected == 1, { selected = 1 }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Riwayat") })
                    NavigationBarItem(selected == 2, { selected = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Pengaturan") })
                }
            }
        ) { pad ->
            when (selected) {
                0 -> Dashboard(Modifier.padding(pad), transactions)
                1 -> History(Modifier.padding(pad), transactions, filter) { filter = it }
                2 -> SettingsPage(Modifier.padding(pad))
            }
        }
    }

    @Composable
    fun Dashboard(modifier: Modifier, txs: List<Transaction>) {
        val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis
        val todayTx = txs.filter { it.time >= today }
        val total = todayTx.sumOf { it.amount }
        Column(modifier.fillMaxSize().padding(16.dp)) {
            Text("Hari ini", fontSize = 14.sp, color = Color.Gray)
            Text(rupiah(total), fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Transaksi", todayTx.size.toString(), Modifier.weight(1f))
                StatCard("Terakhir", todayTx.firstOrNull()?.let { rupiah(it.amount) } ?: "-", Modifier.weight(1f))
            }
            Spacer(Modifier.height(18.dp))
            Text("Pembayaran terbaru", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (txs.isEmpty()) EmptyState()
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(txs.take(10), key = { it.id }) { TransactionRow(it) }
            }
        }
    }

    @Composable
    fun History(modifier: Modifier, txs: List<Transaction>, filter: String, onFilter: (String)->Unit) {
        val shown = txs.filter {
            filter == "SEMUA" || (filter == "DANA" && it.provider == Provider.DANA) ||
            (filter == "SHOPEEPAY" && it.provider == Provider.SHOPEEPAY)
        }
        Column(modifier.fillMaxSize().padding(16.dp)) {
            Text("Riwayat transaksi", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SEMUA","DANA","SHOPEEPAY").forEach { f ->
                    FilterChip(selected = filter == f, onClick = { onFilter(f) }, label = { Text(f) })
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { TransactionRow(it) }
            }
        }
    }

    @Composable
    fun SettingsPage(modifier: Modifier) {
        Column(modifier.fillMaxSize().padding(20.dp)) {
            Text("Pengaturan", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Card(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Akses notifikasi", fontWeight = FontWeight.Bold)
                    Text("Aktifkan akses agar QRIS Notifier dapat membaca notifikasi pembayaran DANA dan ShopeePay.", color = Color.Gray, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { openNotificationAccess() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.NotificationsActive, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Aktifkan akses notifikasi")
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Privasi", fontWeight = FontWeight.Bold)
            Text("Data transaksi disimpan secara lokal di perangkat. Aplikasi ini tidak memerlukan login DANA atau ShopeePay.", color = Color.Gray, fontSize = 13.sp)
        }
    }

    @Composable
    fun StatCard(title: String, value: String, modifier: Modifier) {
        Card(modifier, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(title, color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(5.dp))
                Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        }
    }

    @Composable
    fun TransactionRow(t: Transaction) {
        Card(shape = RoundedCornerShape(14.dp)) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (t.provider == Provider.DANA) Icons.Default.AccountBalanceWallet else Icons.Default.QrCode2, null, tint = Green)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.provider.name, fontWeight = FontWeight.Bold)
                    Text(t.sender, fontSize = 13.sp, color = Color.Gray)
                    Text(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id","ID")).format(Date(t.time)), fontSize = 11.sp, color = Color.Gray)
                }
                Text(rupiah(t.amount), fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    fun EmptyState() {
        Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.NotificationsNone, null, modifier = Modifier.size(42.dp), tint = Color.Gray)
                Text("Belum ada pembayaran terdeteksi", color = Color.Gray)
                Text("Aktifkan akses notifikasi di Pengaturan.", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

fun rupiah(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("id","ID")).apply { maximumFractionDigits = 0 }.format(value)
