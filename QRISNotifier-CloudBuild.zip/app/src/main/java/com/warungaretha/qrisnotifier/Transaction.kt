package com.warungaretha.qrisnotifier

data class Transaction(
    val id: Long,
    val provider: Provider,
    val amount: Long,
    val sender: String,
    val title: String,
    val rawText: String,
    val time: Long
)

enum class Provider { DANA, SHOPEEPAY, UNKNOWN }
