package com.warungaretha.qrisnotifier

import android.app.Notification
import android.os.Bundle
import java.util.Locale

object QrisNotificationParser {
    private val danaPackages = setOf(
        "id.dana", "com.dana"
    )
    private val shopeePackages = setOf(
        "com.shopee.id", "com.shopee"
    )

    fun parse(packageName: String, extras: Bundle, postedAt: Long): Transaction? {
        val provider = when {
            packageName in danaPackages -> Provider.DANA
            packageName in shopeePackages -> Provider.SHOPEEPAY
            else -> return null
        }

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val combined = listOf(title, text, big).filter { it.isNotBlank() }.joinToString(" | ")
        val lower = combined.lowercase(Locale.ROOT)

        // Guard against unrelated notifications.
        val paymentWords = listOf("diterima", "menerima", "pembayaran", "payment", "qr", "qris", "masuk", "berhasil", "received")
        if (paymentWords.none { lower.contains(it) }) return null

        val amount = extractAmount(combined) ?: return null
        val sender = extractSender(combined)

        return Transaction(
            id = postedAt xor combined.hashCode().toLong(),
            provider = provider,
            amount = amount,
            sender = sender,
            title = title.ifBlank { "Pembayaran masuk" },
            rawText = combined,
            time = postedAt
        )
    }

    private fun extractAmount(s: String): Long? {
        val patterns = listOf(
            Regex("""(?i)(?:rp|idr)\s*([0-9][0-9\.\,\s]*)"""),
            Regex("""(?i)(?:nominal|jumlah|amount|sebesar)\D{0,10}([0-9][0-9\.\,\s]*)""")
        )
        for (p in patterns) {
            val m = p.find(s) ?: continue
            val digits = m.groupValues[1].filter(Char::isDigit)
            if (digits.isNotBlank()) return digits.toLongOrNull()
        }
        return null
    }

    private fun extractSender(s: String): String {
        val patterns = listOf(
            Regex("""(?i)(?:dari|from|pengirim)\s*[:\-]?\s*([A-Za-z][A-Za-z0-9 ._-]{2,40})"""),
            Regex("""(?i)(?:oleh|by)\s*[:\-]?\s*([A-Za-z][A-Za-z0-9 ._-]{2,40})""")
        )
        return patterns.firstNotNullOfOrNull { it.find(s)?.groupValues?.getOrNull(1)?.trim() } ?: "Pembayaran QRIS"
    }
}
