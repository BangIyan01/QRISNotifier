package com.warungaretha.qrisnotifier

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class TransactionStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("qris_store", Context.MODE_PRIVATE)

    fun load(): List<Transaction> {
        val raw = prefs.getString("transactions", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(Transaction(
                    o.getLong("id"),
                    Provider.valueOf(o.getString("provider")),
                    o.getLong("amount"),
                    o.optString("sender"),
                    o.optString("title"),
                    o.optString("rawText"),
                    o.getLong("time")
                ))
            }
        }.sortedByDescending { it.time }
    }

    @Synchronized fun add(t: Transaction) {
        val list = load().toMutableList()
        if (list.any { it.id == t.id }) return
        list.add(0, t)
        val arr = JSONArray()
        list.take(500).forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("provider", it.provider.name); put("amount", it.amount)
                put("sender", it.sender); put("title", it.title); put("rawText", it.rawText); put("time", it.time)
            })
        }
        prefs.edit().putString("transactions", arr.toString()).apply()
    }

    fun clear() = prefs.edit().remove("transactions").apply()
}
