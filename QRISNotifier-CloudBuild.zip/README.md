# QRIS Notifier

Aplikasi Android untuk memusatkan notifikasi pembayaran QRIS dari DANA dan ShopeePay.

## Fitur
- Dashboard total transaksi hari ini
- Riwayat transaksi
- Filter Semua / DANA / ShopeePay
- Deteksi otomatis melalui Android Notification Listener
- Penyimpanan lokal hingga 500 transaksi
- Tidak membutuhkan login ke DANA/ShopeePay

## Cara menjalankan
1. Buka folder ini di Android Studio terbaru.
2. Tunggu Gradle Sync selesai.
3. Jalankan di HP Android.
4. Buka QRIS Notifier > Pengaturan > Aktifkan akses notifikasi.
5. Pastikan notifikasi DANA/ShopeePay diizinkan muncul.
6. Lakukan transaksi uji.

## Catatan
Nama package aplikasi DANA/ShopeePay dapat berbeda antar versi/region. Jika notifikasi belum terbaca, cek package name aplikasi pada perangkat dan tambahkan ke `QrisNotificationParser.kt`.

Parser sengaja hanya menyimpan transaksi ketika notifikasi terlihat seperti pembayaran dan memiliki nominal Rupiah. Format notifikasi pihak ketiga dapat berubah, sehingga regex mungkin perlu disesuaikan.

Aplikasi hanya membaca notifikasi yang diberikan Android kepada NotificationListenerService; tidak mengakses akun atau server DANA/ShopeePay.
