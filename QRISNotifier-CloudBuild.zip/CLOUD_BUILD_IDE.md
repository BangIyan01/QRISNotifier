# Build QRIS Notifier dari HP dengan GitHub Actions

1. Buat akun/login GitHub di Chrome.
2. Buat repository baru, misalnya `QRISNotifier`.
3. Upload semua isi proyek ini ke repository.
4. Buka tab **Actions**.
5. Pilih workflow **Build QRIS Notifier APK**.
6. Tekan **Run workflow** (atau push ke branch main untuk menjalankan otomatis).
7. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
8. Download `QRIS-Notifier-debug`.
9. Extract ZIP dan install `app-debug.apk` di HP.

Tidak perlu Android Studio dan tidak perlu laptop.

Catatan:
- GitHub Actions membangun APK debug.
- Android mungkin meminta izin "install unknown apps" saat memasang APK.
- Untuk rilis publik/Play Store, APK sebaiknya dibuat signed release.
